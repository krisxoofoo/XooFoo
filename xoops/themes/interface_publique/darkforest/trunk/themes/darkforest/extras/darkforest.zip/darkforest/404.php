<?php get_header(); ?>
<!-- Container -->

<div class="CON">
  <?php get_sidebar(); ?>
  <!-- Start SC -->
  <div class="SC">
    <div class="SC_f">
      <h2 class="pagetitle">Error 404</h2>
      <p>Page Not Found</p>
    </div>
  </div>
  <!-- End SC -->
</div>
<!-- End CON -->
<?php get_footer(); ?>
