<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
<?php $theTitle=wp_title(" - ", false); if($theTitle != "") { ?>
<title><?php echo wp_title("",false); ?>-
<?php bloginfo('name'); ?>
</title>
<?php } else { ?>
<title>
<?php bloginfo('name'); ?>
</title>
<?php } ?>
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<meta http-equiv="pragma" content="no-cache" />
<meta http-equiv="cache-control" content="no-cache" />
<link rel="stylesheet" type="text/css" href="<?php bloginfo('stylesheet_url'); ?>" />
<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>" />
<link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="<?php bloginfo('atom_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<?php wp_head(); ?>
</head>
<body>
<div bg id="bgcontainer">
<!-- START Header -->
<div class="Header">
  <div class="Logo">
    <div class="LogoText">
      <h1><a href="<?php echo get_option('home'); ?>">
        <?php bloginfo('name'); ?>
        </a></h1>
    </div>
    <p class="Desc">
      <?php bloginfo('description'); ?>
    </p>
  </div>
  <div class="Syn">
    <ul>
      <li><a href="<?php bloginfo('rss2_url'); ?>">Entries</a> (RSS) <a href="<?php bloginfo('comments_rss2_url'); ?>">Comments</a> (RSS)</li>
    </ul>
  </div>
  <div class="clr"></div>
  <div class="Menu">
    <ul>
      <li><a href="<?php echo get_option('home'); ?>">Home</a></li>
      <li><a href="<?php echo get_option('home'); ?>?page_id=2">About Us</a></li>
      <li><a href="<?php echo get_option('home'); ?>?m=200808">Archives</a></li>
      <li><a href="<?php echo get_option('home'); ?>?page_id=3">Contact Us</a></li>
    </ul>
  </div>
  <div class="clr"></div>
</div>
<!-- END Header -->
