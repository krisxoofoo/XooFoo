<div class="SR">
  <!-- Start SideBar2 -->
  <div class="SRR">
    <!-- Start Categories -->
    <div class="widget widget_categories">
      <h2>Categories</h2>
      <ul>
        <?php wp_list_cats('show_count=1'); ?>
      </ul>
    </div>
    <!-- End Categories -->
    <!-- Start Archives -->
    <div class="widget widget_archives">
      <h2>Archives</h2>
      <ul>
        <?php wp_get_archives('type=monthly'); ?>
      </ul>
    </div>
    <!-- End Archives -->
    <!-- Start Links -->
    <div class="widget widget_links">
      <h2>Links</h2>
      <ul>
        <li><a href="http://codex.wordpress.org/">Documentation</a></li>
        <li><a href="http://wordpress.org/development/">Development Blog</a></li>
        <li><a href="http://wordpress.org/extend/ideas/">Suggest Ideas</a></li>
        <li><a href="http://wordpress.org/support/">Support Forum</a></li>
        <li><a href="http://wordpress.org/extend/plugins/">Plugins</a></li>
        <li><a href="http://wordpress.org/extend/themes/">Themes</a></li>
        <li><a href="http://planet.wordpress.org/">WordPress Planet</a></li>
      </ul>
    </div>
    <!-- End Links -->
    <!-- Start Meta -->
    <div class="widget widget_meta">
      <h2>Meta</h2>
      <ul>
        <?php wp_register(); ?>
        <li>
          <?php wp_loginout(); ?>
        </li>
        <li><a href="http://validator.w3.org/check/referer" title="This page validates as XHTML 1.0 Transitional">Valid <abbr title="eXtensible HyperText Markup Language">XHTML</abbr></a></li>
        <li><a href="http://gmpg.org/xfn/"><abbr title="XHTML Friends Network">XFN</abbr></a></li>
        <li><a href="http://wordpress.org/" title="Powered by WordPress, state-of-the-art semantic personal publishing platform.">WordPress</a></li>
        <?php wp_meta(); ?>
      </ul>
    </div>
    <!-- End Meta -->
    <!-- Start Search -->
    <div class="Search">
      <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
        <h2>Search</h2>
        <input type="text" name="s" class="keyword" />
        <div class="bt">
          <input name="submit" type="submit" class="search" title="Search" alt="Search" value="Go" />
        </div>
      </form>
      <div class="clr"></div>
    </div>
    <!-- End Search -->
  </div>
  <!-- End SideBar2 -->
</div>
