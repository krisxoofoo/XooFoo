<?php get_header(); ?>
<div id="outer">
<div id="inner">
	<div id="container">
    	<div class="search">
        <form method="get" id="searchform" action="<?php bloginfo('url'); ?>/">
        <input type="text" value="<?php the_search_query(); ?>" name="s" id="s" class="txtField" />
        <input type="submit" id="searchsubmit" class="btnSearch" value="Find It &raquo;" />
        </form>
        </div>
        <div id="blog-title">
        <span class="title"><a href="<?php echo get_option('home'); ?>/"><?php bloginfo('name'); ?></a></span>
        <span class="description"><?php bloginfo('description'); ?></span>
        </div>
        <div class="col01">
        <div class="cat-title">Browsing all posts in: <strong><?php single_cat_title(''); ?></strong></div>
        <!-- begin post -->
		<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>
        	<div class="post" id="post-<?php the_ID(); ?>">
            <h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h2>
            <div class="post-content">
            <div class="tab-date">
            	<span class="month"><?php the_time('F') ?></span>
                <span class="day"><?php the_time('j') ?></span>
            </div>
            <?php the_content('Read the rest of this entry &raquo;'); ?>
            </div>
            </div>
            <?php comments_template(); ?>
			<?php endwhile; ?>
            <?php else : ?>
			<?php endif; ?>
            <!-- end post -->
        </div>
        <?php include ('columns.php'); ?>
        <br clear="all" />
    </div>
<?php get_footer(); ?>