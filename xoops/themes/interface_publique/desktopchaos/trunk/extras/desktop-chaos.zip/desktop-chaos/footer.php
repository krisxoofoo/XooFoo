    <div id="footer">
    	<div class="inner">&copy;<?php the_time('Y') ?> <a href="<?php echo get_option('home'); ?>/"><?php bloginfo('name'); ?></a><br />
        This awesome site <a href="<?php echo get_option('home'); ?>/"><?php bloginfo('name'); ?></a> uses the <a href="http://www.desktopchaos.com">"Desktop Chaos"</a> theme.</div>
        <span class="icon-rss"><a href="<?php bloginfo('rss2_url'); ?>">RSS feed</a></span>
        <span class="icon-ele"><a href="http://www.evaneckard.com">Evan Eckard Design</a></span>
    </div>
</div></div>
</body>
</html>