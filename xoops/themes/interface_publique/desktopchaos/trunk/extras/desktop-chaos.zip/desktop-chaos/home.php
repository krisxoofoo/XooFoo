<?php get_header(); ?>
<div id="outer">
<div id="inner">
	<div id="container">
    	<div class="search">
        <form method="get" id="searchform" action="<?php bloginfo('url'); ?>/">
        <input type="text" value="<?php the_search_query(); ?>" name="s" id="s" class="txtField" />
        <input type="submit" id="searchsubmit" class="btnSearch" value="Find It &raquo;" />
        </form>
        </div>
        <div id="blog-title">
        <span class="title"><a href="<?php echo get_option('home'); ?>/"><?php bloginfo('name'); ?></a></span>
        <span class="description"><?php bloginfo('description'); ?></span>
        </div>
        <div class="col01">
        <!-- begin post -->
		<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>
        	<div class="post" id="post-<?php the_ID(); ?>">
            <h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h2>
            <div class="post-content">
            <div class="tab-date">
            	<span class="month"><?php the_time('F') ?></span>
                <span class="day"><?php the_time('j') ?></span>
            </div>
            <?php the_content('Read the rest of this entry &raquo;'); ?>
            </div>
            <div class="meta"><?php the_category(', ') ?> &nbsp;|&nbsp; <?php comments_popup_link('No Comments &#187;', '1 Comment &#187;', '% Comments &#187;'); ?></div>
            </div>
			<?php endwhile; ?>
            <div class="post-nav"><span class="previous"><?php next_posts_link('&laquo; Older Entries') ?></span><span class="next"><?php previous_posts_link('Newer Entries &raquo;') ?></span></div>
            <?php else : ?>
            <div class="no-results">
            <h3>Not Found</h3>
            <p>Sorry, but you are looking for something that isn't here.</p>
            </div>
			<?php endif; ?>
            <!-- end post -->
        </div>
        <?php include ('columns.php'); ?>
        <br clear="all" />
    </div>
<?php get_footer(); ?>